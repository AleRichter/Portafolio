var urlParams = new URLSearchParams(window.location.search);
var username = urlParams.get('usuario');

document.addEventListener('DOMContentLoaded', function () {
    if (username) {
        document.getElementById('Mensaje de Bienvenida').textContent = '¡Bienvenido/a ' + username + '!';
    } else {
        document.getElementById('Mensaje de Bienvenida').textContent = 'Usuario no especificado';
    }
});



function confirmacion() {
    var nombre = document.getElementById('nombre').value;
    var apellido = document.getElementById('apellido').value;
    var email = document.getElementById('email').value;


    if (nombre !== '' && apellido !== '' && email !== '') {
       alert("Asistencia reservada correctamente");
    } else {
        alert('Verifique los datos del formulario');
    }
}



function alerta()
    {
    var mensaje;
    var opcion = confirm("Estas a punto de cancelar la Clase. Toca aceptar si vas a concurrir.");
    if (opcion == true) {
        mensaje = "Voy a asistir";
	} else {
	    mensaje = "No voy a asistir";
	}
    document.getElementById("btn1").innerHTML = mensaje;
}



