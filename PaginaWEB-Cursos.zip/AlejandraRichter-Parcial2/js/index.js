let button = document.getElementById('myButton');
let input = document.getElementById("myInput");
let span = document.getElementById("message");

document.getElementById("loginForm").addEventListener("submit", function (event) {
  event.preventDefault();

  var username1 = document.getElementById('username').value;
  var password1 = document.getElementById('password').value;
  var username2 = document.getElementById('username').value;
  var password2 = document.getElementById('password').value;

  if (username1 === 'agustina' && password1 === '123') {
    var url = "alumno.html?usuario=" + username1;
    window.location.href = "./alumno..html";
    window.location.href = url;
  }
  else if (username2 === 'rodrigo' && password2 === '123') {
    var url = "docente.html?usuario=" + username2;
    window.location.href = "./docente.html";
    window.location.href = url;
  }
  else {
    alert("Usuario Incorrecto");
  }
});



























